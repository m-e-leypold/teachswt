/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: cpu.hh,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_cpu_HH
#define H_INCLUDED_cpu_HH

#include "MARKUP.h"

namespace cpu {

  typedef unsigned char byte;
  typedef int address;
  typedef int byte_count;
}

#endif /*  H_INCLUDED_cpu_HH */
