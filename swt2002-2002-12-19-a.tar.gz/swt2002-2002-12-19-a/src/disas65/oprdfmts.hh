/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: oprdfmts.hh,v $ $Revision: 1.4 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_oprdfmts_HH
#define H_INCLUDED_oprdfmts_HH

#include "MARKUP.h"


namespace oprdfmts {

  typedef ABSTRACT_HEAP_( oprdfmt );

  int
  max_digits(oprdfmt* ofp);

  int
  max_len(oprdfmt* ofp);

  void
  format(oprdfmt* ofp, int, char* buf); 
  
  /* ^ for this to work, every value (read: operand) formatted must
     fit into an int */

  oprdfmt*
  new_oprdfmt(const char* fmtstr); 
  
  /* ^ must be a 0-terminated string of the format
     
     ^[^%\\]*%0[1-9]x[^%\\]*$ 

  */
  
  void 
  free_oprdfmt(oprdfmt* ofp);

}

				          
#endif /*  H_INCLUDED_oprdfmts_HH */





