/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: TEMPLATE.hh,v $ $Revision: 1.1 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_TEMPLATE_HH
#define H_INCLUDED_TEMPLATE_HH

#include "YYYYYY.hh"       /* <--> USES module 'YYYYYY' */

  /* XXXXXX: your #includes go here */


namespace TEMPLATE {

  /* XXXXXX: your code goes here    */

}

#endif /*  H_INCLUDED_TEMPLATE_HH */
