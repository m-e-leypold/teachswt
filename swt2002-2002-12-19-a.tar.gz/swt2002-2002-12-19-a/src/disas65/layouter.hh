/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: layouter.hh,v $ $Revision: 1.5 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_layouter_HH
#define H_INCLUDED_layouter_HH

#include "MARKUP.h"

#include "instr-texts.hh"

namespace layouter {
  
  typedef ABSTRACT_HEAP_( job );

  typedef struct{
    const char* line_format;
    int         pagelen;
    int         topmargin;
    int         headskip;
    int         titleskip;  
    int         leftmargin; } layout_format;
  
  job*
  new_job(layout_format* lf, const char* headline);

  void
  print_title(job* jb,
              const char* filename,
	      int         dsstart,
              int         dslen,
              int         csstart,
              int         cslen      );

  void
  print_line(job* jb, 
	     instr_texts::instr_text it);

  int
  end_job();
  
  
}

#endif /*  H_INCLUDED_layouter_HH */
