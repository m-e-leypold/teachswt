/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: MARKUP.h,v $ $Revision: 1.2 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_MARKUP_H
#define H_INCLUDED_MARKUP_H

#define ABSTRACT_(impl)      impl
#define ABSTRACT_VAR_(impl)  ABSTRACT_(impl)
#define ABSTRACT_VAL_(impl)  ABSTRACT_(impl)
#define ABSTRACT_HEAP_(name) struct _##name##_ name

/* 
   XXX

   storage strategy: responsibility, ownership, clients,
   storagecontract.
   
   if anyone keeps the storage ownership an idea where the storage
   comes from, must be implied.
   
   ziel eines _guten_ entwurf: dekomposition des systemzustandes in ein
   kartesisches produkt von werten.

   e-xact-e-ly where oo completely fails -> make a paper from that :-)

*/

#endif /*  H_INCLUDED_MARKUP_H */






