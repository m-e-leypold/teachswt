/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: opcodes.hh,v $ $Revision: 1.5 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_opcodes_HH
#define H_INCLUDED_opcodes_HH

#include "MARKUP.h"

#include "cpu.hh"
#include "oprdfmts.hh"

namespace opcodes {

  typedef ABSTRACT_VAL_(int)    opcode;
  typedef struct{ char t[4] ;} mnemonic;       /* mnemonic.t[3]==0 always */

  opcode          from_byte(cpu::byte b);
  
  mnemonic        
  mnemonic_of(opcode oc);

  oprdfmts::oprdfmt
  oprd_fmt_of(opcode oc);

  int             
  instr_len(opcode oc);

  int
  is_legal(cpu::byte b);
  
  void 
  define_opcode(cpu::byte b, 
		mnemonic m,
		oprdfmts::oprdfmt of, 
		int instr_len);

  void
  init_module();

  void
  deinit_module();
}

#endif /*  H_INCLUDED_opcodes_HH */








