/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: main.cc,v $ $Revision: 1.6 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/


#include "layouter.hh"
#include "disassembly.hh"

#include "programs.hh"
#include "addrmodes.hh"
#include "opcodes.hh"
#include "instrs.hh"
#include "instr-texts.hh"

typedef struct{
  
  const char*               opcodes_filename;
  const char*               addrmodes_filename;
  layouter::layout_format   lf;                        } configuration;
  
void
set_default_config(configuration* cfgp);

void
read_config_files(configuration* cfgp);

char*
parse_commandline(int argc, char** argv, configuration* cfgp);

void
build_tables(const char* opcodes_filename, const char* addrmodes_filename);

void
disassemble_file(const char* filename);

int
main(int argc, char** argv);







