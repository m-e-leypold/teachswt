/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: programs.hh,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_programs_HH
#define H_INCLUDED_programs_HH
  
#include "MARKUP.h"
#include <stdio.h>

#include "cpu.hh"

namespace programs {

  typedef ABSTRACT_HEAP_( program ); /* immutable */
  typedef ABSTRACT_HEAP_( segment ); /* immutable */

  program*
  NEW_from_file(FILE* f);
  
  const segment*
  codeseg_of(program* p);

  const segment*
  dataseg_of(program* p);

  void
  FREE(program* p);

  /* segments */

  cpu::byte_count
  length_of(const segment* s);

  cpu::address
  address_of(const segment* s);

  const cpu::byte*
  image_of(const segment* s);

}

#endif /*  H_INCLUDED_programs_HH */
