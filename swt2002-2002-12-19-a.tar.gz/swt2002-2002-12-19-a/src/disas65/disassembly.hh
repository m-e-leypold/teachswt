/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: disassembly.hh,v $ $Revision: 1.5 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_disassembly_HH
#define H_INCLUDED_disassembly_HH

#include "programs.hh"
#include "instrs.hh"
#include "instr-texts.hh"
#include "cpu.hh"

namespace disassembly {
  
  typedef struct{
   
    int           len;
    instrs::instr ins[]; }  instrs_list;

  cpu::byte_count
  parse(const programs::segment* s, instrs_list* il);

  void
  DEINIT_instr_list(instrs_list* il);
  
  void
  disassemble(const char* af,
              instrs::instr in, 
	      instr_texts::instr_text* it);

}

#endif /*  H_INCLUDED_disassembly_HH */






