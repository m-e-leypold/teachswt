/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: operands.hh,v $ $Revision: 1.4 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_operands_HH
#define H_INCLUDED_operands_HH

#include "MARKUP.h"

#include "cpu.hh"
#include "oprdfmts.hh"

namespace operands {

  typedef ABSTRACT_VAL_( struct{ 

    int size; 
    int val;                  }) operand;

  operand
  from_bytes(int size, cpu::byte* b);

  char *               /* freshy malloc'ed */
  format(oprdfmts::oprdfmt* ofp, operand od);


  /* you don't need these, my friend 

  int
  val_of(operand od);

  
  int
  size_of(operand od);

  */

}


#endif /*  H_INCLUDED_operands_HH */


