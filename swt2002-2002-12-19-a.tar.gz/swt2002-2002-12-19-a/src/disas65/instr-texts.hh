/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: instr-texts.hh,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_instr_texts_HH
#define H_INCLUDED_instr_texts_HH

#include "opcodes.hh"

namespace instr_texts {

  typedef struct{
    const char*         addr_text; 
    opcodes::mnemonic   mn;
    const char*         oprd_text; }    instr_text;
  
  void
  INIT_instr_text(instr_text* it, 
                  const char* addr_text, 
		  opcodes::mnemonic mn, 
		  const char* oprd_text);

  void
  DEINIT_instr_text(instr_text* it);

}

#endif /*  H_INCLUDED_instr_texts_HH */
