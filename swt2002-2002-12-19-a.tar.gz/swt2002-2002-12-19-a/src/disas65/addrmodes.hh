/*
  disas65 -- skeleton code for a 6502 assembler as part of an exercise
  in software engineering.

  $RCSfile: addrmodes.hh,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_addrmodes_HH
#define H_INCLUDED_addrmodes_HH

#include "MARKUP.h"

#include "oprdfmts.hh"



namespace addrmodes {

  typedef ABSTRACT_VAL_(int)    addrmode;


  addrmode from_string(const char* txtp);

  oprdfmts::oprdfmt
  oprd_fmt_of(addrmode am);

  int             
  oprd_len(addrmode am);


  /* Module / ADT initialization */

  addrmode 
  add_addrmode(oprdfmts::oprdfmt* ofp, int oprd_len, const char* textrepr);

  void
  init_module();

  void
  deinit_module();
}

#endif /*  H_INCLUDED_addrmodes_HH */








