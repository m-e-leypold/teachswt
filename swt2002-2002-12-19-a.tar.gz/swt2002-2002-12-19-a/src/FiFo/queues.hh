/*
  Blatt 2: Interface zum Modul 'queues'
  (L�sung / Codebeispiel zur Vorlesung "Softwaretechnik" 2002)

  $RCSfile: queues.hh,v $ $Revision: 1.4 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/



#ifndef HH_INCLUDED_queues
#define HH_INCLUDED_queues

#include <sys/types.h>

#include "jobs.hh"               /* IMPORT jobs                    */

namespace queues {               /* DEFINE queues                  */

  const size_t len_max = 5; 

  typedef struct {              /* structure PRIVATE to the module */
    size_t   len;               /* INVARIANT: len <= len_max.      */
    jobs::desc data[len_max];   /* data[0] ... data[len-1]         */
                                /*   are the content of the queue. */
  } queue;


  void
  init (queue* q);

  int
  is_empty(queue* q);

  int 
  insert (queue* q, /* in/move  */  jobs::desc* jp);
  
  void
  next   (queue* q, /* out/move */  jobs::desc* jp);

}

#endif /* HH_INCLUDED_queues defined */






