/*
  Blatt 2: Implementation des Moduls 'jobs'
  (L�sung / Codebeispiel zur Vorlesung "Softwaretechnik" 2002)

  $RCSfile: jobs.cc,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/


#include "jobs.hh"               /* IMPLEMENT jobs                  */

#include <string.h>              /* USING strdup() + friends        */
#include <stdlib.h>              /* USING malloc() + friends        */

namespace jobs { 

  struct DESC {
    char* title;
    char* file;
  };

  void 
  init   (desc* d, const char* title, const char* file)
  {
    (*d)=(struct DESC*)malloc(sizeof(*d));  /* see comment [1]    */
    (*d)->title=strdup(title);              /* see comment [1]    */
    (*d)->file=strdup(file);
  };

  const char*
  title_of (desc* d)
  {
    return (*d)->title;
  };

  const char*
  filename_of (desc* d)
  {
    return (*d)->file;
  };

  void
  copy (desc* s, desc* d)
  {
    init(d, (*s)->title, (*s)->file);
  };
  
  void
  move (desc* s, desc* d){
    (*d)=(*s); (*s)=0;
  };
  
  void
  deinit (desc* d){
    free((*d)->file);
    free((*d)->title);
    free(*d);
  };
}



/* COMMENTS:

   [1] not yet written XXX

*/




