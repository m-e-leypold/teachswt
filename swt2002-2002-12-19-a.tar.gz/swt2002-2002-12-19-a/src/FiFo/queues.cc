/*
  Blatt 2: Implementation des Moduls 'queues'
  (L�sung / Codebeispiel zur Vorlesung "Softwaretechnik" 2002)

  $RCSfile: queues.cc,v $ $Revision: 1.4 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/

#include "queues.hh" /* IMPLEMENT queue */
namespace queues {
  
  void
  init (queue* q)
  {
    q->len=0;
  };

  int
  is_empty(queue* q)
  {
    return q->len==0;
  };

  int 
  insert(queue* q, jobs::desc* jp)
  {
    if (q->len>=len_max) return 0;
    jobs::move(jp,q->data+q->len);
    q->len++;
    return -1;                       /* return TRUE on success */
  };
  
  void
  next(queue* q, jobs::desc* jp)
  {
    size_t        i;

    jobs::move(q->data+0,jp);

    for (i=1; i<(q->len); i++){
      jobs::move(q->data+i,q->data+(i-1));
    }
    q->len--;
  };

}








