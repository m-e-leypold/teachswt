/*
  Blatt 2: Interface zum Modul 'jobs'
  (L�sung / Codebeispiel zur Vorlesung "Softwaretechnik" 2002)

  $RCSfile: jobs.hh,v $ $Revision: 1.4 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/



#ifndef HH_INCLUDED_jobs
#define HH_INCLUDED_jobs

namespace jobs {                /* DEFINE jobs                     */

  typedef struct DESC (* desc); 

  void 
  init   (desc* d, const char* title, const char* file);

  const char*
  title_of (desc* d);

  const char*
  file_of (desc* d);

  void
  copy (desc* s, desc* d);
  
  void
  move (desc* s, desc* d);

  void
  deinit (desc* d);
}

#endif /* HH_INCLUDED_jobs defined */



