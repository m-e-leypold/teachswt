/*
  Blatt 2: Module 'testschedule' (Hauptmodul des Testbetts)
  (L�sung / Codebeispiel zur Vorlesung "Softwaretechnik" 2002)

  $RCSfile: testschedule.cc,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/

#include "jobs.hh"
#include "queues.hh"

#include <stdio.h>

/* tables for test data */

const char* titles[] = { 
  "Diplomarbeit Illec",
  "Testdruck 4Farben",
  "Buch der 1000erlei Kr�uter",
  "Power C++ in 2 Tagen",
  "Schattenparker",
  "Schattenparker 2",
  "Die R�ckkehr der Schattenparker"
};


const char* files[] = { 
  "cutomers/illec.ps",
  "testing/4cols.ps",
  "customers/1000-kraeuter.ps",
  "customer/powerc++.ps",
  "archive/schattenp1.ps",
  "archive/schattenp2.ps",
  "archive/schattenp3.ps"
};

#define NR_ELEMNS(x) (sizeof(x)/sizeof(*x))

const int no_of_jobs = NR_ELEMNS(titles);


int
main(int argc, char* argv[])
{
  int i;
  int success;
  
  jobs::desc       jd;
  queues::queue     q;

  queues::init(&q);

  printf("\nstarting test: %s.\n","queuing.");

  for (i=0; i<no_of_jobs; i++){

    printf("queuing: %s.\n",titles[i]);
   
    jobs::init(&jd,titles[i],files[i]);

    success=queues::insert(&q,&jd);

    if (!success) {
      printf("could not be queued: %s.\n",jobs::title_of(&jd));
      jobs::deinit(&jd);
    }
  };

  printf("\ncontinuing test: %s.\n","dequeuing.");

  while (! queues::is_empty(&q)){
    queues::next(&q,&jd);
    printf("dequeued: %s.\n",jobs::title_of(&jd));
    jobs::deinit(&jd);
  };
    
  printf("\ntest completed.\n");
  return 0;
};









