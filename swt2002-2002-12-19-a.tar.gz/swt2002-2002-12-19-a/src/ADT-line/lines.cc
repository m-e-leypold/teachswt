/*
  Partial implementation of the ADT 'line'.
  
  Adapted from: EFASS (editor for a small system).

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. 
*/

#include <sys/types.h> /* need size_t               */
#include <stdlib.h>    /* need malloc() and friends */
#include <string.h>    /* need memcpy() and friends */

namespace lines {

  typedef struct{    /* PRIVATE. You're not supposed to  */
    char* store;     /* use any knowledge about the      */
    size_t  dlen;    /* components of this structure.    */
    size_t  slen;
  }                  /* ==> */     line  ;

  void
  insert_char(line* p, char c, size_t pos){
    size_t nlen;

    nlen = p->dlen+1;

    if (!(p->slen)>=nlen) {                    /* [1] */
      p->store=(char*)realloc(p->store, nlen); 
      p->slen=nlen;
    }
    
    memmove(p->store+1+pos,p->store+pos,p->dlen-pos);
    p->dlen++;
    p->store[pos]=c;
  }
};
