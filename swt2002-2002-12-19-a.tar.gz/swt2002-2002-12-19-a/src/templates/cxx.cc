
#include "XXX.hh" /* implements XXX interface */
namespace XXX {

  XXX your stuff here

}
