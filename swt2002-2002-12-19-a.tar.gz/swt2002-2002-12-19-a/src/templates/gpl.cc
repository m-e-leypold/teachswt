/*
  XXX 
  (L�sung / Codebeispiel zur Vorlesung "Softwaretechnik" 2002)

  $RCSfile: gpl.cc,v $ $Revision: 1.1 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/
