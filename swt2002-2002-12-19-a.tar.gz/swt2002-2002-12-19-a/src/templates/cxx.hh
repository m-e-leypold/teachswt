#ifndef HH_INCLUDED_XXX
#define HH_INCLUDED_XXX

namespace XXX {

 XXX xour stuff here

}

#endif /* HH_INCLUDED_XXX defined */
