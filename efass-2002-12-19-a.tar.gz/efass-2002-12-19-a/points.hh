/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: points.hh,v $ $Revision: 1.10 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/

#ifndef H_INCLUDED_POINTS_HH
#define H_INCLUDED_POINTS_HH

#include <sys/types.h>
#include <stdio.h>

namespace points {    /* <--> DEFINES 'points' interface */

  void
  init();

  int
  load(FILE *);

  int
  save(FILE *);

  void
  get_line(int line_no, char** pp, int* n);

  size_t
  get_point_x();

  size_t
  get_point_y();

  void
  set_point(size_t x, size_t y);

  void
  move_right();

  void
  move_left();

  void
  move_up();

  void
  move_down();

  void
  insert_char(unsigned char c);  

  void
  split_line();  
  
  void
  remove();

  void
  remove_backwards();

}


#endif /* H_INCLUDED_POINTS_HH */
