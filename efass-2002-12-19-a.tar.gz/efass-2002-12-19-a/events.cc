/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: events.cc,v $ $Revision: 1.8 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#include "events.hh"     /* <--> IMPLEMENTS 'events' module */

#include "keyboard.hh"   /* <--> USES 'keyboard' module */

#include <sys/types.h>
#include <string.h>

namespace events {

  char    buffer[100];

  /* needs to be longer than the longest char-sequence bound to an
     event. a ringbuffer implementation would doubtless have been more
     efficient, but also more complex. */
  
  typedef struct{
    char* s;
    event_type e;
  }                      /* ==> */  binding_type;


#define SK "\033\133"

  binding_type binding[14] = {

    {{ "\016"          }, { EV_C_DOWN   }},
    {{ SK "\102"       }, { EV_C_DOWN    }},

    {{ "\002"          }, { EV_C_LEFT    }},
    {{SK "\104"        }, { EV_C_LEFT    }},

    {{"\006"           }, { EV_C_RIGHT   }},
    {{SK "\103"        }, { EV_C_RIGHT   }},

    {{"\020"           }, { EV_C_UP      }},
    {{SK "\101"        }, { EV_C_UP      }},

    {{"\030"           }, { EV_CMD_EXIT  }},
    {{"\001"           }, { EV_CMD_ABORT }},

    {{"\012"           }, { EV_K_RETURN  }},
    {{"\010"           }, { EV_K_BS      }},

    {{"\177"           }, { EV_K_DEL     }},
    {{SK "\063\176"    }, { EV_K_DEL     }}
  };


  static int
  is_printable(unsigned char c){
    if (c<' ')  return  0;
    if (c<127)  return -1;
    if (c==127) return  0;
    if (c<160)  return  0;
    return -1;
  }


  void
  init(){
    keyboard::init();
    buffer[0]='\000';
  };

  void
  deinit(){
    keyboard::deinit();
  };

  static void
  get_char(){
    size_t l;

    l=strlen(buffer);
    buffer[l]=keyboard::get_char();
    buffer[l+1]='\000';
    l++;
  };

  static void
  consume_chars(int n){
    size_t l;

    l=strlen(buffer);
    memcpy(buffer,buffer+n,l);
  };

  
  static int
  is_prefix(char *s1, char *s2){

    while(((*s1)==(*s2)) && (*s1) && (*s2)){ s1++; s2++; }
    
    return !(*s1);
  }


  static int
  match_bindings(event *e){

    /* return no of binding (if found), -1 if need more characters and
       -2 binding not found */

    /* we need more input, if the buffer is nonempty + a true prefix
       (that is: not identical) to any char sequence in binding[]. we
       have found a binding, if the binding is a prefix of the buffer */

    int no_of_bindings;
    binding_type* b;
    int need_more;
    int found;

    if ('\000'==(*buffer)) return -1;

    no_of_bindings=sizeof(binding)/sizeof(binding_type);
    
    found=-2; need_more=0;
    for (b=binding;b<(binding+no_of_bindings);b++){
	if (is_prefix(b->s,buffer)) {
	  found=(b-binding);
	}
	if (is_prefix(buffer,b->s) && (!(0==strcmp(buffer,b->s)))) {
	  need_more=-1;
	}
    }
    if (need_more) return -1;
    return found;
  };      


  event
  get_event(){

    event e;
    unsigned char  c;
    int b;   
    
    do {
      while (-1==(b=match_bindings(&e))) {
	get_char();
      };
      
      if (b>=0) {
	consume_chars(strlen(binding[b].s));
	e.t=binding[b].e;
      } else {
	c=(*buffer);
        consume_chars(1);
	e.t=EV_CHAR;
	e.chr=c;
      };
    } while ((b<0) && (! (is_printable(c))));

    return e;
  };
  


}





