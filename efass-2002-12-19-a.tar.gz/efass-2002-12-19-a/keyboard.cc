/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: keyboard.cc,v $ $Revision: 1.4 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.

*/

#include "keyboard.hh"  /* <--> IMPLEMENTS 'keyboard' interface */

#include <stdio.h>
#include "tty.hh"       /* <--> USES tty module                 */

namespace keyboard{  

  void
  init(){
    tty::init();
  }

  void
  deinit(){
    tty::restore();
  }

  unsigned char
  get_char(){
    unsigned char c;

    c=fgetc(stdin);
    return c;
  };
}














