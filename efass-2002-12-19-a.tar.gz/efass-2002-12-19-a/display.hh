/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: display.hh,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.  
*/

#ifndef H_INCLUDED_DISPLAY_HH
#define H_INCLUDED_DISPLAY_HH

#include <stdio.h>

namespace display { /* <--> DEFINES 'diplay' interface */


  void 
  clear();

  void 
  init();

  int 
  get_width();

  int 
  get_height();

  void 
  set_line(int line_no, char* s, int n);

  void 
  set_cursor(int x, int y);

};

#endif







