
/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: keyboard.hh,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.

*/

namespace keyboard{  /* <--> DEFINES 'keyboard' interface */

  void
  init();

  void
  deinit();
    
  unsigned char
  get_char();
}


























