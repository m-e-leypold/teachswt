/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: tty.cc,v $ $Revision: 1.2 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  

  Terminal handling procedure to switch a the terminal (which is
  supposed to be at STDIN_FILENO and stdin) into cbreak mode and back
  again. Adapted from: "Advanced Programming in the UNIX Environment"
  by R. Stevens, p 354.  

*/


#include <unistd.h>
#include <termios.h>
#include <stdio.h>

namespace tty{

  static struct termios save_termios;
  static int    fd   = -1;
  static FILE*  file =  0;
  static enum {RESET, RAW, CBREAK } ttystate = RESET;
  
  int
  set_cbreak_mode(){ /* put tty into cbreak mode */
    
    struct termios buf;
  
    if (tcgetattr(fd, &save_termios) < 0) return -1;
    
    buf = save_termios;
    
    buf.c_lflag    &=  ~(ECHO | ICANON);
    buf.c_cc[VMIN]  =  1;
    buf.c_cc[VTIME] =  0;
    
    if (tcsetattr(fd, TCSAFLUSH, &buf) < 0) return -1;
    
    ttystate  = CBREAK;
    
    return 0;
  }

  int restore(){
    if (ttystate!=CBREAK && ttystate!=RAW)           return  0;

    if (tcsetattr(fd, TCSAFLUSH, &save_termios) < 0) return -1;
    ttystate = RESET;
    return 0;
  }

  void
  init(){
    fd   = STDIN_FILENO;
    file = stdin;

    fflush(file);
    set_cbreak_mode();
  };
};





