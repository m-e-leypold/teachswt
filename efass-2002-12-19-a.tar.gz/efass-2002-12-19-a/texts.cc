/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: texts.cc,v $ $Revision: 1.10 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.

*/


#include  "texts.hh"      /* <--> IMPLEMENTS 'texts' module           
                             ---> implies USAGE of 'lines' module     */

#include <sys/types.h> 
#include <stdlib.h>       /* need malloc() */
#include <string.h>
#include <assert.h>

using namespace lines;    /* unqualified IMPORT of names from 'lines' */

namespace texts {

  typedef struct{
    line*         store;
    size_t        len;
    size_t        blen;
  }                     /* ==> */     text  ;

  const static size_t initial_blen = 32;

  static text T;
  
  void
  init(){
    T.blen=32;
    T.len=0;
    T.store=(line*)malloc((sizeof(*(T.store)))*T.blen);  /* XXX this
                                                            is bad */
  };

  size_t
  length(){
    return T.len;
  }

  static void
  ensure_blen(size_t blen){

    if ((T.blen)>=blen) return;
    T.store=(line*)realloc(T.store,blen*(sizeof(*(T.store))));/* XXX bad */
    T.blen=blen;
  };

  void
  ensure_length(size_t len){
    size_t i;

    if (T.len>=len) return;
    ensure_blen(len);
    for (i=T.len;i<len;i++){
      lines::init(T.store+i,0,0);
    }
    T.len=len;
  }
  

  void
  insert_char(unsigned char c, size_t line_no, size_t pos){

    assert(line_no<=T.len); assert(line_no>0);

    lines::insert_char(T.store+line_no-1, c, pos);
  };



  void
  remove_char(size_t line_no, size_t pos){

    assert(line_no<=T.len); assert(line_no>0);

    lines::remove_char(T.store+line_no-1, pos);
  };
  

  static void
  ensure_free_store(size_t n){
    ensure_blen(T.len+n);
  };


  static void
  insert_slot(size_t line_no){
    assert(line_no<=T.len); assert(line_no>=0);

    ensure_free_store(1);
    memmove(T.store+1+line_no,T.store+line_no,
	    (T.len-line_no)*sizeof(*T.store));
    T.len++;
  }


  static void
  remove_slot(size_t line_no){
    assert(line_no<=T.len); assert(line_no>0);

    memmove(T.store+line_no-1,T.store+line_no,
	    (T.len-line_no)*sizeof(*T.store));
    T.len--;
  }


  void
  split_line(size_t line_no, size_t pos){

    assert(line_no<=T.len); assert(line_no>0);    
    
    insert_slot(line_no);
    lines::split(T.store+line_no-1,pos,T.store+line_no);
  };


  void
  merge_lines(size_t line_no){

    assert(line_no<T.len); assert(line_no>0);    

    lines::merge(T.store+line_no-1,T.store+line_no);
    lines::deinit(T.store+line_no);
    remove_slot(line_no+1);
  };

  lines::line*
  get_line(size_t n){
    assert(n>0); assert(n<=T.len);

    return T.store+n-1;
  };


  int
  load(FILE* f){

    assert(T.len==0); /* avoid trouble collecting already alloc'ed lines */
    
    ensure_blen(T.len+1);

    while (lines::load(T.store+T.len,f)){
      T.len++;
      ensure_blen(T.len+1);
    }

    return !(ferror(f)); /* was that a regular feof() or an error ? */
  }



  int
  save(FILE* f){
    
    size_t i;
    int    ok;

    printf("!!!!!!!!!\n");

    for (i=1;i<=T.len;i++) {
      ok=lines::save(T.store+i-1,f);
      if (!ok) return ok;
    }
    return 0;
  }


#ifdef EFASS_DEBUG_PROCEDURES
  
  void
  set_line(size_t line_no, char* s){
    ensure_length(line_no);
    assign_cstr(T.store+line_no-1,s);
  }
  
  void
  printf_text(char* f){ 
    size_t i;
    
    for (i=0;i<T.len;i++) 
      {printf_line(f,T.store+i);}
  }
  
#endif /* EFASS_DEBUG_PROCEDURES */
}


