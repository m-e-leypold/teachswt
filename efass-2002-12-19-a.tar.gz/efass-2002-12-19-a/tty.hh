
/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: tty.hh,v $ $Revision: 1.2 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.

*/

namespace tty{      /* <--> DEFINES 'tty' interface */
  
  int
  set_cbreak_mode();

  int 
  restore();

  void
  init();
};





