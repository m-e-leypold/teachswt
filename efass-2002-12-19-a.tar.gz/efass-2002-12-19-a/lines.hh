/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: lines.hh,v $ $Revision: 1.8 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/


#ifndef H_INCLUDED_LINES_HH
#define H_INCLUDED_LINES_HH

#include <sys/types.h>
#include <stdio.h>

namespace lines {    /* <--> DEFINES 'lines' interface */

  typedef struct{    /* PRIVATE. You're not supposed to  */
    char* store;     /* use any knowledge about the      */
    size_t  len;     /* components of this structure.    */
    size_t  blen;
  }                  /* ==> */     line  ;

  void
  init(line* p, char* s, size_t n);

  int
  load(line* p, FILE* f);

  int
  save(line* p, FILE* f);
  
  void
  deinit(line* p);

  size_t
  length(line* p);

  void
  insert_char(line* p, char c, size_t pos);

  void
  remove_char(line* p, size_t pos);

  void
  split(line* p, size_t pos, line* q);

  void
  merge(line* p, line* q);

  void
  get_chars(line* p, char** sp, int* np);


#ifdef EFASS_DEBUG_PROCEDURES

  line*
  new_line(char* s, size_t n);

  void 
  assign_cstr(line* p, char* s);

  void
  printf_line(char* f,line* p);

#endif /* EFASS_DEBUG_PROCEDURES */

}
#endif /* H_INCLUDED_LINES_HH */



