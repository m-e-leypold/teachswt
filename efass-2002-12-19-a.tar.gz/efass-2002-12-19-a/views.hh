/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: views.hh,v $ $Revision: 1.7 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/

#ifndef H_INCLUDED_VIEWS_HH
#define H_INCLUDED_VIEWS_HH


#include <stdio.h>

namespace views {    /* <--> DEFINES 'views' interface */

  void
  init(int w, int h);

  int
  load(FILE *);

  int
  save(FILE *);

  void
  get_line(int line_no, char** pp, int* n);

  int
  get_cursor_x();

  int
  get_cursor_y();

  void
  move_right();

  void
  move_left();

  void
  move_up();

  void
  move_down();

  void
  insert_char(unsigned char c);

  void
  split_line();

  void
  remove();

  void
  remove_backwards();

}

#endif /* H_INCLUDED_VIEWS_HH */
