/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: lines.cc,v $ $Revision: 1.10 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#include "lines.hh"   /* <--> IMPLEMENTS 'lines' interface */ 

#include <stdlib.h>   /* need malloc() and friends */
#include <string.h>
#include <assert.h>

namespace lines {

  static const int 
  initial_blen = 10;  /* should also be standard slack increment ! */
  
  #define ASSERT_BLEN_OK(p) {assert((p->len)<=(p->blen));}
  /*
    Das ist die Invariante der Repraesentation des 'line' ADT
  */

  static void
  ensure_blen(line* p, size_t blen){

    if ((p->blen)>=blen) return;
    
    /* if ((p->blen+initial_blen)>blen) blen=p->blen+initial_blen; */

    p->store=(char*)realloc(p->store, blen); /* XXX bad */
    p->blen=blen;
    
    ASSERT_BLEN_OK(p);
  };

  static void
  ensure_free_store(line* p, size_t n){
    ensure_blen(p, p->len+n);
  };


  void
  init(line* p, char* s, size_t n){
    
    if (s==0){ p->blen=initial_blen;   p->len=0; }
    else     { p->blen=initial_blen+n; p->len=n; }
    
    p->store=(char*)malloc(p->blen);  /* XXX this is bad */
    if (s) strncpy(p->store,s,n);
  };

  void
  deinit(line* p){
    free(p->store);
  }
  
  size_t
  length(line* p){
    return p->len;
  }

  void
  insert_char(line* p, char c, size_t pos){

    assert(pos>=0); assert(pos<=p->len);

    ensure_free_store(p,1);
    memmove(p->store+1+pos,p->store+pos,p->len-pos);
    p->len++;
    p->store[pos]=c;

    ASSERT_BLEN_OK(p);
  }


  void
  remove_char(line* p, size_t pos){

    assert(pos>0); assert(pos<=p->len);
    
    memmove(p->store+pos-1,p->store+pos,p->len-pos+1);
    p->len--;
  }

  void
  split(line* p, size_t pos, line* q){

    assert(pos>=0); assert(pos<=p->len);

    init(q,p->store+pos,p->len-pos);
    p->len=pos;

    /* ASSERT: results p and q concatenated would give
       initial p again */
  };

  void
  merge(line* p, line* q){
    
    ensure_blen(p,p->len+q->len);
    strncpy(p->store+p->len,q->store,q->len);
    p->len+=q->len;

    /* ASSERT: result p is initial p + q concatenated */
  };



  void
  get_chars(line* p, char** sp, int* np){
    (*sp)=p->store;
    (*np)=p->len;
  };

  
  int
  load(line* p, FILE* f){
    size_t h;

    init(p,0,0); h=0;
    
    while(fgets(p->store+h,p->blen-h,f)) {

      h=h+strlen(p->store+h);

      if (h && (*(p->store+h-1)=='\n')){
	h--;         /* throw away trailing newline */
	p->len=h;      
	return -1;
      }

      if (feof(f)) { /* end of file without trailing newline */
	p->len=h;      
	return -1;
      }

      /* we need to read more -- get more buffer */
      ensure_blen(p,p->blen+initial_blen);
    
    } /* and loop ... */

    deinit(p); /* free storage again             */
    return 0;  /* couldn't sucessfully load line */
  };



  int
  save(line* p, FILE* f){

    size_t n;

    n = fwrite( p->store, 
		/* size  */ sizeof(*(p->store)), 
		/* nmemb */ p->len, 
		f);
    if (n!=p->len) return 0;

    return ('\n'==putc('\n',f));
  } 



#ifdef EFASS_DEBUG_PROCEDURES


  void
  assign_cstr(line* p, char* s){
    size_t n;
    
    n=strlen(s);
    ensure_blen(p, n);
    strncpy(p->store,s,n);
    p->len=n;
  }

  static char*
  strndup(char *s, size_t n){
    char* d;
    if (!(d=(char*)malloc(n+1))) 
      return 0;                    /* the spirit of strdup - OK  :-) */
    strncpy(d,s,n);
    d[n]='\0';
    return d;
  }


  void
  printf_line(char* f,line* p){
    char* s;

    s=strndup(p->store,p->len); /* XXX bad */
    printf(f,s);
    free(s);
    fflush(0);
  }

  /* not actually needed, therefore not exposed: new_line */

  line*
  new_line(char* s, size_t n){
    line* p;
    p=(line*)malloc(sizeof(line));   /* XXX this is bad */
    init(p,s,n);
    return p;
  }

#endif /* EFASS_DEBUG_PROCEDURES */

};





