/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: texts.hh,v $ $Revision: 1.8 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
*/

#ifndef H_INCLUDED_TEXTS_HH
#define H_INCLUDED_TEXTS_HH

#include "lines.hh"        /* <--> USES 'lines' module       */

#include <sys/types.h>     /* using 'size_t' type            */

namespace texts {          /* <--> DEFINES 'texts' interface */

  void
  init();

  int
  load(FILE* f);

  int
  save(FILE* f);

  size_t
  length();

  lines::line*
  get_line(size_t n);

  void
  insert_char(unsigned char c, size_t line_no, size_t pos);

  void
  remove_char(size_t line_no, size_t pos);

  void
  split_line(size_t line_no, size_t pos);

  void
  merge_lines(size_t line_no);

  void
  ensure_length(size_t n);

#ifdef EFASS_DEBUG_PROCEDURES
  
  void
  printf_text(char* f);

  void
  set_line(size_t line_no, char* s);

#endif /* EFASS_DEBUG_PROCEDURES */

}

#endif /* H_INCLUDED_TEXTS_HH */

