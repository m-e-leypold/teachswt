/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: events.hh,v $ $Revision: 1.6 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#ifndef H_INCLUDED_EVENTS_HH
#define H_INCLUDED_EVENTS_HH

namespace events {     /* <--> DEFINES 'events' interface */

  typedef enum {       /* PUBLIC ! */
    EV_CHAR,
    EV_C_UP,
    EV_C_DOWN,
    EV_C_LEFT,
    EV_C_RIGHT,
    EV_K_RETURN,
    EV_K_DEL,
    EV_K_BS,
    EV_CMD_EXIT,
    EV_CMD_ABORT
  }                    /* ==> */ event_type ;

  typedef struct {     /* PUBLIC ! */
    event_type   t;
    char         chr;    
  }                    /* ==> */   event;

  void
  init();

  void
  deinit();

  event
  get_event();
}


#endif /*  H_INCLUDED_EVENTS_HH */
