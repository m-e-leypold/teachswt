/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: show-keys.cc,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#include "debug-aids.h"

#include "keyboard.hh"  /* <--> USES 'keyboard' module */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include <unistd.h>


int 
main(int argc, char** argv){

  signed char c;

  keyboard::init();

  for(;;) {
    
    c=keyboard::get_char();
    printf("%d\n",c);
  };
  
}












