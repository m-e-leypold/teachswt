/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 
  
  $RCSfile: efass.cc,v $ $Revision: 1.18 $
  
  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#include "views.hh"     /* <--> USES 'views' module (ado)           */ 
#include "display.hh"   /* <--> USES 'display' module (hw)          */ 
#include "events.hh"    /* <--> USES 'events' module (hw)           */

#include <unistd.h>     /* need sleep() et al */
#include <stdio.h>      /* need ANSI files    */
#include <string.h>

static int   v_width;    
static int   v_height;
static FILE* f;
  
static char* msg_banner[3] =
{
 " EFASS - (visual) editor for a small system. (C) 2002 M E Leypold.",
 " EFASS comes with ABSOLUTELY NO WARRANTY and is free software.",
 " See LICENSE.txt for details."
};


static char* msg_init    = "... initializing ... ";
static char* msg_load    = "... loading file ... ";
static char* msg_save    = "... saving file ... ";
static char* msg_argv    = "Bad argument(s): Aborted.";
static char* msg_openerr = "Can't open file: Aborted.";

void
update_screen(){
  
  int i;
  char* s;
  int   n;

  for (i=1;i<=v_height;i++){
    views::get_line(i,&s,&n);
    display::set_line(i,s,n);
  }

  display::set_cursor
    (views::get_cursor_x(), views::get_cursor_y());
}


void
show_message(char* s){
  display::set_line(6,s,strlen(s));
  sleep(1);
};


int
process_event(){

  events::event e;

  for (;;){
    e=events::get_event();
    switch (e.t) {
    case events::EV_CHAR     : views::insert_char(e.chr); return -1;
    case events::EV_C_RIGHT  : views::move_right(); return -1;
    case events::EV_C_LEFT   : views::move_left(); return -1;
    case events::EV_C_UP     : views::move_up(); return-1;
    case events::EV_C_DOWN   : views::move_down(); return -1;      
    case events::EV_K_RETURN : views::split_line(); return -1;
    case events::EV_K_DEL    : views::remove(); return -1;
    case events::EV_K_BS     : views::remove_backwards(); return -1;

    case events::EV_CMD_EXIT : 
      display::clear();
      show_message(msg_save);
      clearerr(f);
      rewind(f);
      views::save(f); 
      return 0;

    case events::EV_CMD_ABORT: return 0;
    }
  }
}




int 
main(int argc, char** argv){

  int err;
  
  display::init();

  display::set_line(1,msg_banner[0],strlen(msg_banner[0]));
  display::set_line(3,msg_banner[1],strlen(msg_banner[1]));
  display::set_line(4,msg_banner[2],strlen(msg_banner[2]));
  show_message(msg_init);

  events::init();
  v_width=display::get_width();
  v_height=display::get_height();
  views::init(v_width,v_height);

  show_message(msg_load);

  if (argc!=2) { show_message(msg_argv); err=1; }
  else {

    f=fopen(argv[1],"r+");
    
    if (!f) { show_message(msg_openerr); err=2;} 
    else {
	
      views::load(f);
      
      display::clear();
      update_screen();
      while(process_event()) update_screen();
      
      fclose(f);
      err=0;
    }
  }
  
  if (!err) display::clear();
  events::deinit();
  display::set_line(8,"",0);

  return err;
}






