/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: debug-aids.h,v $ $Revision: 1.3 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.

*/
#ifndef H_INCLUDED_DEBUG_AIDS_H
#define H_INCLUDED_DEBUG_AIDS_H

#include <stdio.h>

#define LOG(f,X) printf(#X" "#f"\n",X)

#endif


