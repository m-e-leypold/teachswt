/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: views.cc,v $ $Revision: 1.9 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#include "views.hh"    /* <--> IMPLEMENTS 'views' module */

#include "points.hh"   /* <--> USES 'points' module */

#include <assert.h>

namespace views {
  
  static int width;
  static int height;
  static int pos_x;
  static int pos_y;

  void
  init(int w, int h){
    width=w;
    height=h;
    points::init();
    pos_x=0;
    pos_y=0;
  };

  int
  load(FILE* f){
    int e;

    e=points::load(f);
    pos_x=0;
    pos_y=0;

    return e;
  }

  int
  save(FILE* f){
    int e;

    e=points::save(f);
    return e;
  }

  void
  get_line(int line_no, char** pp, int* n){
    
    points::get_line(line_no+pos_y,pp,n);
    
    if ((*n)<pos_x) { *n=0; *pp=0; return;}
    
    (*pp) += pos_x;
    (*n)  -= pos_x;
    if ((*n) > width) (*n)=width;

    return;
  };


  int
  get_cursor_x(){
    return (points::get_point_x())-pos_x;
  }

  int
  get_cursor_y(){
    return (points::get_point_y())-pos_y;
  }


  static void
  scroll_right(size_t n){
    pos_x += n;
  }

  static void
  scroll_left(size_t n){
    pos_x -= n;
  }

  static void
  scroll_up(size_t n){
    pos_y -= n;
  }

  static void
  scroll_down(size_t n){
    pos_y += n;
  }


  #define ASSERT_CURSOR_VISIBLE \
          assert(get_cursor_x()>0); \
          assert(get_cursor_y()>0); \
          assert(get_cursor_x()<=width); \
          assert(get_cursor_y()<=height);


  static void
  ensure_visible_cursor(){

    int x,y;

    x=get_cursor_x();
    y=get_cursor_y();
    
    if (x<1) scroll_left(1-x);
    else {
      if (x>width) scroll_right(x-width);
    }

    if (y<1) scroll_up(1-y);
    else {
      if (y>height) scroll_down(y-height);
    }

    ASSERT_CURSOR_VISIBLE;
  }


  void
  insert_char(unsigned char c){
    points::insert_char(c);
    ensure_visible_cursor();
  }

  void
  split_line(){
    points::split_line();
    ensure_visible_cursor();
  }

  void
  remove(){
    points::remove();
    ensure_visible_cursor();
  }

  void
  remove_backwards(){
    points::remove_backwards();
    ensure_visible_cursor();
  }

  void
  move_right(){
    points::move_right();
    ensure_visible_cursor();
  }

  void
  move_left(){
    points::move_left();
    ensure_visible_cursor();
  }
  
  void
  move_up(){
    points::move_up();
    ensure_visible_cursor();
  }

  void
  move_down(){
    points::move_down();
    ensure_visible_cursor();
  }

}
  










