/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: points.cc,v $ $Revision: 1.10 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/


#include "points.hh"    /* <--> IMPLEMENTS 'points' module */
#include "texts.hh"     /* <--> USES 'texts' module */

#include "assert.h"

namespace points {

  static size_t pos_x;
  static size_t pos_y; /* := line number */

  
  void
  init(){
    texts::init();
    pos_x=1;
    pos_y=1;
  };

  static void
  ensure_text_length(){
    texts::ensure_length(pos_y);
  };


  int
  load(FILE* f){
    int e;

    e=texts::load(f);
    pos_x=1;
    pos_y=1;
    ensure_text_length();
    return e;
  };


  int
  save(FILE* f){
    return (texts::save(f));
  };


  static lines::line*
  _get_line(int line_no){
    return(texts::get_line(line_no));
  }


  #define ASSERT_POINT_Y_IN_BOUNDS { \
		 assert(pos_y>0); \
		 assert(pos_y<=texts::length()); }

  size_t 
  line_length(int line_no){
 
    ASSERT_POINT_Y_IN_BOUNDS;   

    return lines::length(_get_line(line_no));
  };


  void 
  get_line(int line_no, char** pp, int* n){

    lines::line* l;

    if ((size_t)line_no>texts::length()) { (*pp)=0; (*n)=0; return; }

    l=texts::get_line(line_no);
    lines::get_chars(l,pp,n);
  };



  size_t 
  get_point_x(){ return pos_x; }

  size_t
  get_point_y(){ return pos_y; }


  #define ASSERT_POINT_X_IN_BOUNDS { \
		 assert(pos_x>0); \
		 assert((pos_x-1)<=line_length(pos_y)); }



  #define ASSERT_POINT_IN_BOUNDS {  \
     	         ASSERT_POINT_Y_IN_BOUNDS; \
     	         ASSERT_POINT_X_IN_BOUNDS; }




  



  static void
  set_in_bounds(){
    size_t h;

    h=texts::length();
    if (pos_y<1) pos_y=1; 
    if (pos_y>h) pos_y=h; 

    ASSERT_POINT_Y_IN_BOUNDS;

    h=line_length(pos_y);
    if (pos_x<1)     pos_x=1; 
    if (pos_x>(h+1)) pos_x=h+1; 

    ASSERT_POINT_IN_BOUNDS;
  }


  static void
  to_line_begin(){
    ASSERT_POINT_Y_IN_BOUNDS;
    
    pos_x=1;
    
    ASSERT_POINT_IN_BOUNDS;
  }


  static void
  to_line_end(){
    ASSERT_POINT_Y_IN_BOUNDS;
    
    pos_x=line_length(pos_y)+1;
    
    ASSERT_POINT_IN_BOUNDS;
  }



  void
  move_up(){
    pos_y--;
    set_in_bounds();
  }

  void
  move_down(){
    pos_y++;
    ensure_text_length();
    set_in_bounds();
  }

  void
  move_right(){

    pos_x++;

    if (pos_x>(line_length(pos_y)+1)){
      to_line_begin();
      move_down();
    }
  }


  void
  move_left(){

    pos_x--;

    if (pos_x<1){
      move_up();
      to_line_end();
    }
  }
  


  void
  insert_char(unsigned char c){
    ASSERT_POINT_IN_BOUNDS;

    texts::insert_char(c,pos_y,pos_x-1); 
    move_right();

    ASSERT_POINT_IN_BOUNDS;
  }


  void
  split_line(){
    ASSERT_POINT_IN_BOUNDS;

    texts::split_line(pos_y,pos_x-1);
    to_line_begin();
    move_down();

    ASSERT_POINT_IN_BOUNDS;
  }

  void
  remove(){
    ASSERT_POINT_IN_BOUNDS;

    if (pos_x>line_length(pos_y)) {
      if (pos_y<texts::length())
	texts::merge_lines(pos_y);
    }
    else {
      texts::remove_char(pos_y,pos_x);
    }
    
    ASSERT_POINT_IN_BOUNDS;
  }




  void
  remove_backwards(){ 

    if (1==pos_x &&(1==pos_y)) return;
    move_left();
    remove();
  }  

}








