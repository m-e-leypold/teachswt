/*
  EFASS (editor for a small system). A case study for a course in
  software engineering. See README.txt for details. 

  $RCSfile: display.cc,v $ $Revision: 1.6 $

  Copyright (C) 2002 M E Leypold. 

  This file is distributed under the GNU GENERAL PUBLIC LICENSE. See
  LICENSE.txt for details.
  
*/

#include  "display.hh"         /* <--> IMPLEMENTS 'diplay' module */

#include <stdio.h>
#include <assert.h>

namespace display {      

  const static int size_x = 80;
  const static int size_y = 25;

  void clear(){
    printf("\033[2J");
  };


  void init(){
    clear();
    return;
  };

  int get_width(){
    return size_x;
  };

  int get_height(){
    return size_y;
  };

  void 
  set_cursor(int x, int y){
    
    assert(x>0); assert(x<=size_x);
    assert(y>0); assert(y<=size_y);

    printf("\033[%d;%dH",y,x);
    fflush(0);
  };


  void 
  set_line(int line_no, char* s, int n){
    size_t i;

    set_cursor(1,line_no);
    for (i=0;i<n;i++) putchar(s[i]);
    printf("\033[?0K");
    fflush(stdout);
  };
};


