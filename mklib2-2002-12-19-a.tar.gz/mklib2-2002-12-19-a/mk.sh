#!/bin/sh
#
#    Mklib make library
#
#    Copyright (C) 2002, M E Leypold
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License as
#    published by the Free Software Foundation; either version 2 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#    02111-1307 USA
#


#!/bin/sh
#
# we should check for a parameter of the form -f and then
# omit '-f Mkfile' --
#

set -e
set +u

form_mklib_path
_MKFILE='-f Mkfile'

for i in "$@"; do if test "$i" = "-f" ; then _MKFILE=''; fi; done

exec make $_MKFILE MAKE=mk `echo "$TMP_PATH" | sed 's|^|-I |;s|:| -I|g'` "$@" -I .

# -I . is actually disputable ...
# actually builds should be started via a shell script which contain
# additional enviroment ...
#
