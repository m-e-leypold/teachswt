#!/bin/sh
#
#    Mklib make library
#
#    Copyright (C) 2002, M E Leypold
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License as
#    published by the Free Software Foundation; either version 2 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#    02111-1307 USA
#


#!/bin/sh

#
# EXTEND THAT
#

S=$1 
F=$2 
shift

set -e
set -u

B=$(basename "$S")

case $B in 
    *.mli) T='mli';M=$(basename "$S" .mli);;
    *.ml)  T='ml' ;M=$(basename "$S" .ml);;
    *)     T='-'  ;M=$(echo "$B" | sed 's|[^.]*$||');;
esac

{
cat <<EOF

# created by      : mkdeps.ocaml
# source file     : $S
# source basename : $B
# module name     : $M
# source type     : $T
# make fragment   : $F

MKFRAG  := $F
ifeq         (\$(strip \$(filter \$(MKFRAG),\$(MKFRAGS))),)
MKFRAGS := \$(MKFRAG) \$(MKFRAGS)

EOF

${OCAMLDEP:-ocamldep} "$@" $S \
| awk -vf="$F" -vm="$M" -vt="$T" -- '


function adddep(m) {
         print " "m" \\"
	 if (m~/\.cmi$/) {
            gsub(/\.cmi$/,"",m);
	    I[m".mli.mk"]="";
	    return;
         } 
	 if (m~/\.cm[xo]$/) {
            gsub(/cm[xo]$/,"ml.mk",m);
	    I[m]="";
	    return;
         } 
}

{
    for (i=1;i<=NF;i++) {
        if ($i~/:$/) {
          gsub(/.*\//,"",$i);
	  print ""
          print $i " \\";
        } else if ($i=="\\") {
          #
        } else {
          gsub(/.*\//,"",$i);
	  adddep($i);
        }
    }
}

END {
    print "\n"
    for (i in I) {
        print "include "i;
    }
    if (t=="ml") print "\n\nOCAML-MODULE-ORDER += " m;
}

'

echo
echo endif
echo

} > $F

